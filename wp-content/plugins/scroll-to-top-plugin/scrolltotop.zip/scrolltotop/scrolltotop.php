<?php
/* 
Plugin Name: Scroll to Top Button
Plugin URI: http://www.dynamicwp.net/plugins/scroll-to-top-plugin/
Version: v1.00
Author: Reza Erauansyah
Author URI: http://dynamicwp.net
Description: A plugin to add a button that can scroll your page to top.

*/
if (!class_exists("DynamicwpToTopButton")) {
	class DynamicwpToTopButton {
		var $adminOptionsName = "DynamicwpToTopButtonAdminOptions";
		function DynamicwpToTopButton() { //constructor
			
		}
		function init() {
			$this->getAdminOptions();
		}
		//Returns an array of admin options
		function getAdminOptions() {
			$totopbuttonAdminOptions = array(
				'image' => '',
				'speed' => '',
				'at' => '')
				;
			$totopOptions = get_option($this->adminOptionsName);
			if (!empty($totopOptions)) {
				foreach ($totopOptions as $key => $option)
					$totopbuttonAdminOptions[$key] = $option;
			}				
			update_option($this->adminOptionsName, $totopbuttonAdminOptions);
			return $totopbuttonAdminOptions;
		}
		
		//Add jquery
		function mypunc(){
			wp_enqueue_script('jquery');
			}

		//Add totop script
		function mypunc2(){

			$totopOptions = $this->getAdminOptions();
			$image = $totopOptions['image'];
			if($image == ''){
				$newimage = plugins_url('scrolltotop/image/up.png');
			}
			else{
			$newimage=$image;
			}
			
			$speed = $totopOptions['speed'];
			if($speed == ''){
				$newspeed = 800;
			}
			else{
			$newspeed=$speed;
			}
			
			$at = $totopOptions['at'];
			if($at == ''){
				$newat = 350;
			}
			else{
			$newat=$at;
			}
			
			echo "
			<script type=\"text/javascript\">
			var scrolltotop={
			//startline: Integer. Number of pixels from top of doc scrollbar is scrolled before showing control
			//scrollto: Keyword (Integer, or \"Scroll_to_Element_ID\"). How far to scroll document up when control is clicked on (0=top).
			setting: {startline:$newat, scrollto: 0, scrollduration:$newspeed, fadeduration:[500, 100]},
			controlHTML: '<img src=\"$newimage\" /></b></div>', //HTML for control, which is auto wrapped in DIV w/ ID=\"topcontrol\"
			controlattrs: {offsetx:5, offsety:5}, //offset of control relative to right/ bottom of window corner
			anchorkeyword: '#top', //Enter href value of HTML anchors on the page that should also act as \"Scroll Up\" links

			state: {isvisible:false, shouldvisible:false},

			scrollup:function(){
				if (!this.cssfixedsupport) //if control is positioned using JavaScript
					this.control.css({opacity:0}) //hide control immediately after clicking it
				var dest=isNaN(this.setting.scrollto)? this.setting.scrollto : parseInt(this.setting.scrollto)
				if (typeof dest==\"string\" && jQuery('#'+dest).length==1) //check element set by string exists
					dest=jQuery('#'+dest).offset().top
				else
					dest=0
				this.body.animate({scrollTop: dest}, this.setting.scrollduration);
			},

			keepfixed:function(){
				var window=jQuery(window)
				var controlx=window.scrollLeft() + window.width() - this.control.width() - this.controlattrs.offsetx
				var controly=window.scrollTop() + window.height() - this.control.height() - this.controlattrs.offsety
				this.control.css({left:controlx+'px', top:controly+'px'})
			},

			togglecontrol:function(){
				var scrolltop=jQuery(window).scrollTop()
				if (!this.cssfixedsupport)
					this.keepfixed()
				this.state.shouldvisible=(scrolltop>=this.setting.startline)? true : false
				if (this.state.shouldvisible && !this.state.isvisible){
					this.control.stop().animate({opacity:1}, this.setting.fadeduration[0])
					this.state.isvisible=true
				}
				else if (this.state.shouldvisible==false && this.state.isvisible){
					this.control.stop().animate({opacity:0}, this.setting.fadeduration[1])
					this.state.isvisible=false
				}
			},
			
			init:function(){
				jQuery(document).ready(function($){
					var mainobj=scrolltotop
					var iebrws=document.all
					mainobj.cssfixedsupport=!iebrws || iebrws && document.compatMode==\"CSS1Compat\" && window.XMLHttpRequest //not IE or IE7+ browsers in standards mode
					mainobj.body=(window.opera)? (document.compatMode==\"CSS1Compat\"? $('html') : $('body')) : $('html,body')
					mainobj.control=$('<div id=\"topcontrol\">'+mainobj.controlHTML+'</div>')
						.css({position:mainobj.cssfixedsupport? 'fixed' : 'absolute', bottom:mainobj.controlattrs.offsety, right:mainobj.controlattrs.offsetx, opacity:0, cursor:'pointer'})
						.attr({title:'Scroll Back to Top'})
						.click(function(){mainobj.scrollup(); return false})
						.appendTo('body')
					if (document.all && !window.XMLHttpRequest && mainobj.control.text()!='') //loose check for IE6 and below, plus whether control contains any text
						mainobj.control.css({width:mainobj.control.width()}) //IE6- seems to require an explicit width on a DIV containing text
					mainobj.togglecontrol()
					$('a[href=\"' + mainobj.anchorkeyword +'\"]').click(function(){
						mainobj.scrollup()
						return false
					})
					$(window).bind('scroll resize', function(e){
						mainobj.togglecontrol()
					})
				})
			}
		}

		scrolltotop.init()

		</script>
		";
		}	

		//Prints out the admin page
		function printAdminPage() {
					$totopOptions = $this->getAdminOptions();
										
					if (isset($_POST['update_DynamicwpToTopButtonSettings'])) { 
						if (isset($_POST['totopbuttonImage'])) {
							$totopOptions['image'] = apply_filters('content_save_pre', $_POST['totopbuttonImage']);
						}
						if (isset($_POST['totopbuttonSpeed'])) {
							$totopOptions['speed'] = $_POST['totopbuttonSpeed'];
						}
						if (isset($_POST['totopbuttonAt'])) {
							$totopOptions['at'] = $_POST['totopbuttonAt'];
						}						
						
						update_option($this->adminOptionsName, $totopOptions);
						
						?>
						<div class="updated"><p><strong><?php _e("Settings Updated.", "DynamicwpToTopButton");?></strong></p></div>
											<?php
											} ?>
						<div class="wrap">
							<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
							<h2>Scroll to Top</h2>
							<br />
							<b>link to your to top button image : </b><br />
							<input type="text" name="totopbuttonImage" value="<?php _e(apply_filters('format_to_edit',$totopOptions['image']), 'DynamicwpToTopButton') ?>" style="width: 75%;" /><br />
							<small>if you let this empty, the plugin will use the default image as to top button</small>
							
							<br /><br />
					
							<b>Scroll Speed (in milisecond): </b><br />
							<input type="text" name="totopbuttonSpeed" value="<?php if ($totopOptions['speed']) {echo $totopOptions['speed'];} else { echo '800'; }?>" style="width: 10%;" /><br />
							<small>if you let this empty, the plugin will use the default speed</small>					
			
							<br /><br />
					
							<b> The button appears after page scrolled down to line: </b><br />
							<input type="text" name="totopbuttonAt" value="<?php if ($totopOptions['at']) {echo $totopOptions['at'];} else { echo '350'; }?>" style="width: 10%;" /><br />
							<small>if you let this empty, the plugin will use the default setting</small>				

							<br /><br />
							<div class="submit">
								<input type="submit" name="update_DynamicwpToTopButtonSettings" value="<?php _e('Update Settings', 'DynamicwpToTopButton') ?>" />	
							</div>
							</form>
						</div>
					<?php
				}//End function printAdminPage()
	
	}

} //End Class DynamicwpToTopButton

if (class_exists("DynamicwpToTopButton")) {
	$dl_pluginSeries = new DynamicwpToTopButton();
}

//Initialize the admin panel
if (!function_exists("DynamicwpToTopButton_ap")) {
	function DynamicwpToTopButton_ap() {
		global $dl_pluginSeries;
		if (!isset($dl_pluginSeries)) {
			return;
		}
		if (function_exists('add_options_page')) {
	add_options_page('<b style="color: #C50606;">Scroll to Top</b>', '<b style="color: #C50606;">Scroll to Top</b>', 9, basename(__FILE__), array(&$dl_pluginSeries, 'printAdminPage'));
		}
	}	
}

//Actions and Filters	
if (isset($dl_pluginSeries)) {
	//Actions
	add_action('admin_menu', 'DynamicwpToTopButton_ap');
	add_action('activate_scrolltotop/scrolltotop.php',  array(&$dl_pluginSeries, 'init'));
	
	if(!is_admin()){
	add_action('init', array(&$dl_pluginSeries, 'mypunc')); 
	add_action('wp_head', array(&$dl_pluginSeries, 'mypunc2'));
	}
}


?>